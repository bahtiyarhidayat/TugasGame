﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.keKiri = New System.Windows.Forms.PictureBox
        Me.keKanan = New System.Windows.Forms.PictureBox
        Me.Ikan = New System.Windows.Forms.PictureBox
        Me.Label1 = New System.Windows.Forms.Label
        CType(Me.keKiri, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.keKanan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Ikan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'keKiri
        '
        Me.keKiri.BackColor = System.Drawing.Color.Transparent
        Me.keKiri.BackgroundImage = Global.iwak.My.Resources.Resources._2
        Me.keKiri.Location = New System.Drawing.Point(342, 113)
        Me.keKiri.Name = "keKiri"
        Me.keKiri.Size = New System.Drawing.Size(158, 143)
        Me.keKiri.TabIndex = 1
        Me.keKiri.TabStop = False
        '
        'keKanan
        '
        Me.keKanan.BackColor = System.Drawing.Color.Transparent
        Me.keKanan.BackgroundImage = Global.iwak.My.Resources.Resources._1
        Me.keKanan.Location = New System.Drawing.Point(131, 111)
        Me.keKanan.Name = "keKanan"
        Me.keKanan.Size = New System.Drawing.Size(163, 145)
        Me.keKanan.TabIndex = 0
        Me.keKanan.TabStop = False
        '
        'Ikan
        '
        Me.Ikan.Location = New System.Drawing.Point(380, 328)
        Me.Ikan.Name = "Ikan"
        Me.Ikan.Size = New System.Drawing.Size(100, 50)
        Me.Ikan.TabIndex = 2
        Me.Ikan.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(243, 343)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Ikan X :"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.iwak.My.Resources.Resources.dasarlautbiru_back
        Me.ClientSize = New System.Drawing.Size(793, 532)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Ikan)
        Me.Controls.Add(Me.keKiri)
        Me.Controls.Add(Me.keKanan)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.keKiri, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.keKanan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Ikan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents keKanan As System.Windows.Forms.PictureBox
    Friend WithEvents keKiri As System.Windows.Forms.PictureBox
    Friend WithEvents Ikan As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
